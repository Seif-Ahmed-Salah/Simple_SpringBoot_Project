package com.konecta.convertly.enums;

public class WeightUnit {

    public enum Weight_Unit 
    {
        GRAM,
        KILOGRAM,
        POUND,
        OUNCE

    }

}
