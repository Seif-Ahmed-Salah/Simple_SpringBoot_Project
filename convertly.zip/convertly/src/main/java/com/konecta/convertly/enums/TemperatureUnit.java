package com.konecta.convertly.enums;

public class TemperatureUnit {

    public enum TempUnit
    {
        CELSIUS,
        FAHRENHEIT,
        KELVIN
    }

}
