package com.konecta.convertly.service;

import org.springframework.stereotype.Service;

import com.konecta.convertly.exception.InvalidUnitException;
import com.konecta.convertly.model.ConversionResponse;

@Service
public class LengthService {
    public ConversionResponse convertLength(String fromUnit, String toUnit, double value) {
        ConversionResponse response = new ConversionResponse();
        double result;
        if (fromUnit.equalsIgnoreCase("meter")) {

            if (toUnit.equalsIgnoreCase("kilometer")) {
                result = value / 1000;
                response.setResult(result);
                response.setFormula(String.format("(%.2f m ÷ 1000) = %.3f km", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("mile")) {
                result = value / 1609;
                response.setResult(result);
                response.setFormula(String.format("(%.2f m ÷ 1609) = %.3f mi", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("inch")) {
                result = value * 39.37;
                response.setResult(result);
                response.setFormula(String.format("(%.2f m * 39.37) = %.2f in", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("foot")) {
                result = value * 3.281;
                response.setResult(result);
                response.setFormula(String.format("(%.2f m * 3.281) = %.2f ft", value, result));
                response.setStatus("success");

            } else {
                throw new InvalidUnitException("Unsupported target unit: " + toUnit + " from source unit: " + fromUnit);

            }

        } else if (fromUnit.equalsIgnoreCase("kilometer")) {

            if (toUnit.equalsIgnoreCase("meter")) {
                result = value * 1000;
                response.setResult(result);
                response.setFormula(String.format("(%.2f km * 1000) = %.3f m", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("mile")) {
                result = value / 1.609;
                response.setResult(result);
                response.setFormula(String.format("(%.2f km ÷ 1.609) = %.3f mi", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("inch")) {
                result = value * 39370.1;
                response.setResult(result);
                response.setFormula(String.format("(%.2f km × 39370.1) = %.2f in", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("foot")) {
                result = value * 3280.84;
                response.setResult(result);
                response.setFormula(String.format("(%.2f km × 3280.84) = %.2f ft", value, result));
                response.setStatus("success");

            } else {
                throw new InvalidUnitException("Unsupported target unit: " + toUnit + " from source unit: " + fromUnit);

            }

        } else if (fromUnit.equalsIgnoreCase("mile")) {

            if (toUnit.equalsIgnoreCase("meter")) {
                result = value * 1609.34;
                response.setResult(result);
                response.setFormula(String.format("(%.2f mi × 1609.34) = %.3f m", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("kilometer")) {
                result = value * 1.609;
                response.setResult(result);
                response.setFormula(String.format("(%.2f mi × 1.609) = %.3f km", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("inch")) {
                result = value * 63360;
                response.setResult(result);
                response.setFormula(String.format("(%.2f mi × 63360) = %.2f in", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("foot")) {
                result = value * 5280;
                response.setResult(result);
                response.setFormula(String.format("(%.2f mi × 5280) = %.2f ft", value, result));
                response.setStatus("success");

            } else {
                throw new InvalidUnitException("Unsupported target unit: " + toUnit + " from source unit: " + fromUnit);

            }

        } else if (fromUnit.equalsIgnoreCase("inch")) {

            if (toUnit.equalsIgnoreCase("meter")) {
                result = value / 39.37;
                response.setResult(result);
                response.setFormula(String.format("(%.2f in ÷ 39.37) = %.3f m", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("kilometer")) {
                result = value / 39370.1;
                response.setResult(result);
                response.setFormula(String.format("(%.2f in ÷ 39370.1) = %.6f km", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("mile")) {
                result = value / 63360;
                response.setResult(result);
                response.setFormula(String.format("(%.2f in ÷ 63360) = %.6f mi", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("foot")) {
                result = value / 12;
                response.setResult(result);
                response.setFormula(String.format("(%.2f in ÷ 12) = %.2f ft", value, result));
                response.setStatus("success");

            } else {
                throw new InvalidUnitException("Unsupported target unit: " + toUnit + " from source unit: " + fromUnit);

            }

        } else if (fromUnit.equalsIgnoreCase("foot")) {

            if (toUnit.equalsIgnoreCase("meter")) {
                result = value / 3.281;
                response.setResult(result);
                response.setFormula(String.format("(%.2f ft ÷ 3.281) = %.3f m", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("kilometer")) {
                result = value / 3280.84;
                response.setResult(result);
                response.setFormula(String.format("(%.2f ft ÷ 3280.84) = %.6f km", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("mile")) {
                result = value / 5280;
                response.setResult(result);
                response.setFormula(String.format("(%.2f ft ÷ 5280) = %.6f mi", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("inch")) {
                result = value * 12;
                response.setResult(result);
                response.setFormula(String.format("(%.2f ft × 12) = %.2f in", value, result));
                response.setStatus("success");

            } else {
                throw new InvalidUnitException("Unsupported target unit: " + toUnit + " from source unit: " + fromUnit);
            }

        } else {
            throw new InvalidUnitException("Unsupported target unit: " + toUnit + " from source unit: " + fromUnit);
        }

        return response;
    }

}
