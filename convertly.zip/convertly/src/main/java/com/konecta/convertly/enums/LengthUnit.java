package com.konecta.convertly.enums;

public class LengthUnit {

    public enum LenUnit 
    {
        METER,
        KILOMETER,
        MILE,
        INCH,
        FOOT
    }
}
