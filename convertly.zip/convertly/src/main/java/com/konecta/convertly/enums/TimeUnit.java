package com.konecta.convertly.enums;

public class TimeUnit {

    public enum Time_Unit
    {
        SECONDS,
        MINUTES,
        HOURS,
        DAYS
    }

}
