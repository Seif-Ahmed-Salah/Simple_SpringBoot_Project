package com.konecta.convertly.service;

public class ConversionService {

}
