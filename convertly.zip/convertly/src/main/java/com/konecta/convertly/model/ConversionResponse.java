package com.konecta.convertly.model;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter @Setter
@AllArgsConstructor
@NoArgsConstructor
public class ConversionResponse
{
    private double result;
    private String formula;
    private String status;

}
