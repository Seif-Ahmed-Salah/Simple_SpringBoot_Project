package com.konecta.convertly.model;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter 
@Setter 
@AllArgsConstructor
@NoArgsConstructor
public class ConversionRequest {

    @NotBlank(message = "Category is required")
    private String category;
    
    @NotBlank(message = "From unit is required")
    private String fromUnit;

    @NotBlank(message = "To unit is required")
    private String toUnit;

    @NotNull(message = "Value is required")
    @Positive(message = "Value must be a positive number")
    private double value;

}
