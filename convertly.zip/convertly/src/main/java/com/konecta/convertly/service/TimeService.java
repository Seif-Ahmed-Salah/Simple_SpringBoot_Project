package com.konecta.convertly.service;

import org.springframework.stereotype.Service;

import com.konecta.convertly.exception.InvalidUnitException;
import com.konecta.convertly.model.ConversionResponse;

@Service
public class TimeService 
{
    public ConversionResponse convertTime(String fromUnit, String toUnit, double value)
    {
        ConversionResponse response=new ConversionResponse();
        double result;
        
        if (fromUnit.equalsIgnoreCase("seconds")) 
        {

            if (toUnit.equalsIgnoreCase("minutes")) {
                result = value / 60;
                response.setResult(result);
                response.setFormula(String.format("(%.2f s ÷ 60) = %.3f min", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("hours")) {
                result = value / 3600;
                response.setResult(result);
                response.setFormula(String.format("(%.2f s ÷ 3600) = %.3f hr", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("days")) {
                result = value / 86400;
                response.setResult(result);
                response.setFormula(String.format("(%.2f s ÷ 86400) = %.3f days", value, result));
                response.setStatus("success");

            } else {
                throw new InvalidUnitException("Unsupported target unit: " + toUnit + " from source unit: " + fromUnit);
            }

        } 
        else if (fromUnit.equalsIgnoreCase("minutes")) 
        {

            if (toUnit.equalsIgnoreCase("seconds")) {
                result = value * 60;
                response.setResult(result);
                response.setFormula(String.format("(%.2f min × 60) = %.2f s", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("hours")) {
                result = value / 60;
                response.setResult(result);
                response.setFormula(String.format("(%.2f min ÷ 60) = %.3f hr", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("days")) {
                result = value / 1440;
                response.setResult(result);
                response.setFormula(String.format("(%.2f min ÷ 1440) = %.3f days", value, result));
                response.setStatus("success");

            } else {
                throw new InvalidUnitException("Unsupported target unit: " + toUnit + " from source unit: " + fromUnit);
            }

        } 
        else if (fromUnit.equalsIgnoreCase("hours")) 
        {

            if (toUnit.equalsIgnoreCase("seconds")) {
                result = value * 3600;
                response.setResult(result);
                response.setFormula(String.format("(%.2f hr × 3600) = %.2f s", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("minutes")) {
                result = value * 60;
                response.setResult(result);
                response.setFormula(String.format("(%.2f hr × 60) = %.2f min", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("days")) {
                result = value / 24;
                response.setResult(result);
                response.setFormula(String.format("(%.2f hr ÷ 24) = %.3f days", value, result));
                response.setStatus("success");

            } else {
                throw new InvalidUnitException("Unsupported target unit: " + toUnit + " from source unit: " + fromUnit);
            }

        } 
        else if (fromUnit.equalsIgnoreCase("days")) 
        {

            if (toUnit.equalsIgnoreCase("seconds")) {
                result = value * 86400;
                response.setResult(result);
                response.setFormula(String.format("(%.2f days × 86400) = %.2f s", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("minutes")) {
                result = value * 1440;
                response.setResult(result);
                response.setFormula(String.format("(%.2f days × 1440) = %.2f min", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("hours")) {
                result = value * 24;
                response.setResult(result);
                response.setFormula(String.format("(%.2f days × 24) = %.2f hr", value, result));
                response.setStatus("success");

            } else {
                    throw new InvalidUnitException("Unsupported target unit: " + toUnit + " from source unit: " + fromUnit);
            }

        } 
        else
        {
            throw new InvalidUnitException("Unsupported target unit: " + toUnit + " from source unit: " + fromUnit);
        }


        return response;
    }

}
