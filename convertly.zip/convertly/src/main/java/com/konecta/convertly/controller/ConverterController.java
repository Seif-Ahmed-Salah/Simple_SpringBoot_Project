package com.konecta.convertly.controller;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.konecta.convertly.enums.Category.CategoryType;
import com.konecta.convertly.enums.LengthUnit.LenUnit;
import com.konecta.convertly.enums.TemperatureUnit.TempUnit;
import com.konecta.convertly.enums.TimeUnit.Time_Unit;
import com.konecta.convertly.enums.WeightUnit.Weight_Unit;
import com.konecta.convertly.model.ConversionRequest;
import com.konecta.convertly.model.ConversionResponse;
import com.konecta.convertly.service.LengthService;
import com.konecta.convertly.service.TemperatureService;
import com.konecta.convertly.service.TimeService;
import com.konecta.convertly.service.WeightService;

import jakarta.validation.Valid;

import org.springframework.web.bind.annotation.RequestParam;


@RestController
public class ConverterController 
{
    @Autowired private LengthService lengthService;
    @Autowired private TemperatureService temperatureService;
    @Autowired private WeightService weightService;
    @Autowired private TimeService timeService;

    @PostMapping("/convert")
    public ConversionResponse converterResponse(@Valid @RequestBody ConversionRequest request)
    {
        String category=request.getCategory();
        String fromUnit=request.getFromUnit();
        String toUnit=request.getToUnit();
        double value=request.getValue();

        if(category.equalsIgnoreCase("length"))
        {
            return lengthService.convertLength(fromUnit, toUnit, value);
        }
        else if(category.equalsIgnoreCase("temperature"))
        {
            return temperatureService.convertTemperature(fromUnit, toUnit, value);
        }
        else if(category.equalsIgnoreCase("time"))
        {
            return timeService.convertTime(fromUnit, toUnit, value);
        }
        else if(category.equalsIgnoreCase("weight"))
        {
            return weightService.convertWeight(fromUnit, toUnit, value);
        }
        else
        {
            ConversionResponse error = new ConversionResponse();
            error.setStatus("error: unknown category");
            error.setFormula(null);
            error.setResult(0);
            return error;
        }
    }

    @GetMapping("/categories")
    public List<String> getCategories()
    {
        return Arrays.stream(CategoryType.values())
                     .map(Enum::name)
                     .collect(Collectors.toList());
    }
    
    @GetMapping("/units")
    public List<String> getCategoriesUnit(@RequestParam String category)
    {
        if(category.equalsIgnoreCase("temperature"))
        {
            return Arrays.stream(TempUnit.values()).map(Enum::name).collect(Collectors.toList());
        }
        else if(category.equalsIgnoreCase("length"))
        {
            return Arrays.stream(LenUnit.values()).map(Enum::name).collect(Collectors.toList());
        }
        else if(category.equalsIgnoreCase("weight"))
        {
            return Arrays.stream(Weight_Unit.values()).map(Enum::name).collect(Collectors.toList());
        }
        else if(category.equalsIgnoreCase("time"))
        {
            return Arrays.stream(Time_Unit.values()).map(Enum::name).collect(Collectors.toList());
        }
        else
        {
            return List.of("Invalid category: ");
        }

    }
    
    @GetMapping("/sample-payload")
     public ConversionRequest getSamplePayload() {
        return new ConversionRequest("temperature", "celsius", "fahrenheit", 25);
    }

    @GetMapping("/health")
    public  String healthCheck() {
        ConversionResponse response = new ConversionResponse();
        response.setStatus("Unit Converter API is up and running");
        return response.getStatus();
    }
    
    
}
