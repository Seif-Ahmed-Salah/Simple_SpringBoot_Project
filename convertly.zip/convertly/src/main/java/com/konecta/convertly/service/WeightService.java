package com.konecta.convertly.service;

import org.springframework.stereotype.Service;

import com.konecta.convertly.exception.InvalidUnitException;
import com.konecta.convertly.model.ConversionResponse;

@Service
public class WeightService {
    public ConversionResponse convertWeight(String fromUnit, String toUnit, double value) 
    {
        ConversionResponse response = new ConversionResponse();
        double result;

        if (fromUnit.equalsIgnoreCase("gram")) 
        {

            if (toUnit.equalsIgnoreCase("kilogram")) {
                result = value / 1000;
                response.setResult(result);
                response.setFormula(String.format("(%.2f g ÷ 1000) = %.3f kg", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("pound")) {
                result = value / 453.592;
                response.setResult(result);
                response.setFormula(String.format("(%.2f g ÷ 453.592) = %.3f lb", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("ounce")) {
                result = value / 28.35;
                response.setResult(result);
                response.setFormula(String.format("(%.2f g ÷ 28.35) = %.3f oz", value, result));
                response.setStatus("success");

            } else {
                throw new InvalidUnitException("Unsupported target unit: " + toUnit + " from source unit: " + fromUnit);
            }

        } 
        else if (fromUnit.equalsIgnoreCase("kilogram")) 
        {

            if (toUnit.equalsIgnoreCase("gram")) {
                result = value * 1000;
                response.setResult(result);
                response.setFormula(String.format("(%.2f kg × 1000) = %.2f g", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("pound")) {
                result = value * 2.20462;
                response.setResult(result);
                response.setFormula(String.format("(%.2f kg × 2.20462) = %.2f lb", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("ounce")) {
                result = value * 35.274;
                response.setResult(result);
                response.setFormula(String.format("(%.2f kg × 35.274) = %.2f oz", value, result));
                response.setStatus("success");

            } else {
                throw new InvalidUnitException("Unsupported target unit: " + toUnit + " from source unit: " + fromUnit);
            }

        } 
        else if (fromUnit.equalsIgnoreCase("pound")) 
        {

            if (toUnit.equalsIgnoreCase("gram")) {
                result = value * 453.592;
                response.setResult(result);
                response.setFormula(String.format("(%.2f lb × 453.592) = %.2f g", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("kilogram")) {
                result = value / 2.20462;
                response.setResult(result);
                response.setFormula(String.format("(%.2f lb ÷ 2.20462) = %.3f kg", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("ounce")) {
                result = value * 16;
                response.setResult(result);
                response.setFormula(String.format("(%.2f lb × 16) = %.2f oz", value, result));
                response.setStatus("success");

            } else {
                    throw new InvalidUnitException("Unsupported target unit: " + toUnit + " from source unit: " + fromUnit);
            }

        } 
        else if (fromUnit.equalsIgnoreCase("ounce")) 
        {

            if (toUnit.equalsIgnoreCase("gram")) {
                result = value * 28.35;
                response.setResult(result);
                response.setFormula(String.format("(%.2f oz × 28.35) = %.2f g", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("kilogram")) {
                result = value / 35.274;
                response.setResult(result);
                response.setFormula(String.format("(%.2f oz ÷ 35.274) = %.3f kg", value, result));
                response.setStatus("success");

            } else if (toUnit.equalsIgnoreCase("pound")) {
                result = value / 16;
                response.setResult(result);
                response.setFormula(String.format("(%.2f oz ÷ 16) = %.3f lb", value, result));
                response.setStatus("success");

            } else {
                throw new InvalidUnitException("Unsupported target unit: " + toUnit + " from source unit: " + fromUnit);
            }

        } 
        else 
        {
            throw new InvalidUnitException("Unsupported target unit: " + toUnit + " from source unit: " + fromUnit);
        }
        return response;
    }

}
