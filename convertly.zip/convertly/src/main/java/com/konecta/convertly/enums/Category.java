package com.konecta.convertly.enums;

public class Category {

    public enum CategoryType
    {
        TEMPERATURE,
        LENGTH,
        WEIGHT,
        TIME
    }

}
