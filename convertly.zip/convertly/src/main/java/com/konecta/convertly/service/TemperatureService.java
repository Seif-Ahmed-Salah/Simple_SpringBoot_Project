package com.konecta.convertly.service;

import org.springframework.stereotype.Service;

import com.konecta.convertly.exception.InvalidUnitException;
import com.konecta.convertly.model.ConversionResponse;

@Service
public class TemperatureService 
{
    public ConversionResponse convertTemperature(String fromUnit, String toUnit, double value)
    {
        ConversionResponse response = new ConversionResponse();
        double result;
    if (fromUnit.equalsIgnoreCase("celsius")) 
    {

        if (toUnit.equalsIgnoreCase("fahrenheit")) {
            result = (value * 9.0 / 5) + 32;
            response.setResult(result);
            response.setFormula(String.format("(%.2f°C * 9/5) + 32 = %.2f°F", value, result));
            response.setStatus("success");

        } else if (toUnit.equalsIgnoreCase("kelvin")) {
            result = value + 273.15;
            response.setResult(result);
            response.setFormula(String.format("%.2f°C + 273.15 = %.2fK", value, result));
            response.setStatus("success");

        } else {
            throw new InvalidUnitException("Unsupported target unit: " + toUnit + " from source unit: " + fromUnit);
        }

    } 
    else if (fromUnit.equalsIgnoreCase("fahrenheit")) 
    {

        if (toUnit.equalsIgnoreCase("celsius")) {
            result = (value - 32) * 5.0 / 9;
            response.setResult(result);
            response.setFormula(String.format("(%.2f°F - 32) * 5/9 = %.2f°C", value, result));
            response.setStatus("success");

        } else if (toUnit.equalsIgnoreCase("kelvin")) {
            result = ((value - 32) * 5.0 / 9) + 273.15;
            response.setResult(result);
            response.setFormula(String.format("((%.2f°F - 32) * 5/9) + 273.15 = %.2fK", value, result));
            response.setStatus("success");

        } else {
                throw new InvalidUnitException("Unsupported target unit: " + toUnit + " from source unit: " + fromUnit);
        }

    } 
    else if (fromUnit.equalsIgnoreCase("kelvin")) 
    {

        if (toUnit.equalsIgnoreCase("celsius")) {
            result = value - 273.15;
            response.setResult(result);
            response.setFormula(String.format("%.2fK - 273.15 = %.2f°C", value, result));
            response.setStatus("success");

        } else if (toUnit.equalsIgnoreCase("fahrenheit")) {
            result = (value - 273.15) * 9.0 / 5 + 32;
            response.setResult(result);
            response.setFormula(String.format("((%.2fK - 273.15) * 9/5) + 32 = %.2f°F", value, result));
            response.setStatus("success");

        } else {
                throw new InvalidUnitException("Unsupported target unit: " + toUnit + " from source unit: " + fromUnit);
        }

    }
    else 
    {
        throw new InvalidUnitException("Unsupported target unit: " + toUnit + " from source unit: " + fromUnit);
    }
        return response;
    }
}


