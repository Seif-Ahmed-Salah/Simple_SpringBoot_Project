package com.konecta.convertly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConvertlyApplicationTests {

	@Test
	void contextLoads() {
	}

}
